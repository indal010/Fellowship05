let site_properties = {
    home_page:"../Pages/new_home.html",
    add_emp_payroll_page:"../Pages/new_payroll_form_js.html"
};